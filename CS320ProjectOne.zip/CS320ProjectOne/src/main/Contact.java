package main;

public class Contact {
	
	//initialize all variables required
	private static final int CONTACT_PHONENUMBER_LENGTH = 10;
	private static final byte CONTACT_ID_LENGTH = 10;
	private static final byte CONTACT_FIRST_NAME_LENGTH = 10;
	private static final byte CONTACT_LAST_NAME_LENGTH = 10;
	private static final byte CONTACT_ADDRESS_LENGTH = 30;
	private static final String STARTER = "STARTER";
	private static final String STARTER_NUMBER = "1234567899";
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	public Contact() {
		this.contactID = STARTER;
		this.firstName = STARTER;
		this.lastName = STARTER;
		this.phoneNumber = STARTER_NUMBER;
		this.address = STARTER;
	}//default constructor
	
	public Contact(String contactID){
		verifyContactID(contactID);
		this.firstName = STARTER;
		this.lastName = STARTER;
		this.phoneNumber = STARTER_NUMBER;
		this.address = STARTER;
	}//contructor if only contactID is entered
	
	public Contact(String contactID, String firstName){
		verifyContactID(contactID);
		updateFirstName(firstName);
		this.lastName = STARTER;
		this.phoneNumber = STARTER_NUMBER;
		this.address = STARTER;
	}//constructor if contactID and firstName are entered
	
	public Contact(String contactID, String firstName, String lastName){
		verifyContactID(contactID);
		updateFirstName(firstName);
		updateLastName(lastName);
		this.phoneNumber = STARTER_NUMBER;
		this.address = STARTER;
	}//constructor if contactID, firstName, and lastName are entered
	
	public Contact(String contactID, String firstName, String lastName, String phoneNumber){
		verifyContactID(contactID);
		updateFirstName(firstName);
		updateLastName(lastName);
		updatePhoneNumber(phoneNumber);
		this.address = STARTER;
	}//contructor if all but address are entered
	
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address){
		verifyContactID(contactID);
		updateFirstName(firstName);
		updateLastName(lastName);
		updatePhoneNumber(phoneNumber);
		updateAddress(address);
	}//constructor if all info is entered
	
	public final String getContactID() {
		return contactID;
	}
	
	public final String getFirstName() {
		return firstName;
	}
	
	public final String getLastName() {
		return lastName;
	}
	
	public final String getPhoneNumber() {
		return phoneNumber;
	}
	
	public final String getAddress() {
		return address;
	}
	
	public void verifyContactID(String contactID) {
		if(contactID == null) {
			throw new IllegalArgumentException("Contact ID cannot be empty");
		}//verifies contact ID has been entered
		else if (contactID.length() > CONTACT_ID_LENGTH) {
			throw new IllegalArgumentException("Contact ID cannot be longer than " + CONTACT_ID_LENGTH + " characters");
		}//verifies contact ID is correct length
		else {
			this.contactID = contactID;
		}
	}
	
	public void updateFirstName(String firstName) {
		if(firstName == null) {
			throw new IllegalArgumentException("First name cannot be null");
		}//verifies first name has been entered
		else if (firstName.length() > CONTACT_FIRST_NAME_LENGTH) {
			throw new IllegalArgumentException("First name cannot be longer than " + CONTACT_FIRST_NAME_LENGTH + " characters");
		}//verifies first name is correct length
		else {
			this.firstName = firstName;
		}
	}
	
	public void updateLastName(String lastName) {
		if(lastName == null) {
			throw new IllegalArgumentException("Last name cannot be null");
		}//verifies last name has been entered
		else if (lastName.length() > CONTACT_LAST_NAME_LENGTH) {
			throw new IllegalArgumentException("Last name cannot be longer than " + CONTACT_LAST_NAME_LENGTH + " characters");
		}//verifies last name is correct length
		else {
			this.lastName = lastName;
		}
	}
	
	public void updatePhoneNumber(String phoneNumber) {
		String regex = "[0-9]+";
		if (phoneNumber == null) {
			throw new IllegalArgumentException("Phone number cannot be empty");
		}//verifies phone number has been entered
		else if (phoneNumber.length() != CONTACT_PHONENUMBER_LENGTH) {
			throw new IllegalArgumentException("Phone number is either too short or too long. Phone numbers must be " 
												+ CONTACT_PHONENUMBER_LENGTH + " long");
		}//verifies phone number is correct length
		else if (!phoneNumber.matches(regex)) {
			throw new IllegalArgumentException("Phone numbers must consist of only numbers");
		}//verifies phone number is only numbers
		else {
			this.phoneNumber = phoneNumber;
		}
	}
	
	public void updateAddress(String address) {
		if(address == null) {
			throw new IllegalArgumentException("Address cannot be empty");
		}//verifies address has been entered
		else if(address.length() > CONTACT_ADDRESS_LENGTH) {
			throw new IllegalArgumentException("Address cannot be longer than " + CONTACT_ADDRESS_LENGTH + " characters");
		}//verifies address is not longer than specified length
		else {
			this.address = address;
		}
	}
}
