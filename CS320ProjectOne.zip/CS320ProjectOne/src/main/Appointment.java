package main;

import java.util.Date;

public class Appointment {

	final private byte APPOINTMENT_ID_LENGTH;
	final private byte APPOINTMENT_DESCRIPTION_LENGTH;
	final private String INITIALIZER;
	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDesc;
	
	{
		APPOINTMENT_ID_LENGTH = 10;
		APPOINTMENT_DESCRIPTION_LENGTH = 50;
		INITIALIZER = "STARTER";
	}
	
	public Appointment() {
		Date today = new Date();
		appointmentID = INITIALIZER;
		appointmentDate = today;
		appointmentDesc = INITIALIZER;
	}
	
	public Appointment(String appointmentID) {
		Date today = new Date();
		verifyAppointmentID(appointmentID);
		appointmentDate = today;
		appointmentDesc = INITIALIZER;
	}
	
	public Appointment(String appointmentID, Date appointmentDate) {
		verifyAppointmentID(appointmentID);
		verifyAppointmentDate(appointmentDate);
		appointmentDesc = INITIALIZER;
	}
	
	public Appointment(String appointmentID, Date appointmentDate, String appointmentDesc) {
		verifyAppointmentID(appointmentID);
		verifyAppointmentDate(appointmentDate);
		verifyAppointmentDescription(appointmentDesc);
	}
	
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentDesc() {
		return appointmentDesc;
	}
	
	public void verifyAppointmentID(String appointmentID) {
		if (appointmentID == null) {
			throw new IllegalArgumentException("Appointment ID must be entered.");
		}
		else if (appointmentID.length() > APPOINTMENT_ID_LENGTH) {
			throw new IllegalArgumentException("Appointment ID cannot exceed " 
												+ APPOINTMENT_ID_LENGTH 
												+ " characters.");
		}
		else {
			this.appointmentID = appointmentID;
		}
	}
	
	public void verifyAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null) {
			throw new IllegalArgumentException("Appointment date must be entered.");
		}
		else if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Appointment date cannot be in the past.");
		}
		else {
			this.appointmentDate = appointmentDate;
		}
	}
	
	public void verifyAppointmentDescription(String appointmentDesc) {
		if (appointmentDesc == null) {
			throw new IllegalArgumentException("Appointment description cannot be empty");
		}
		else if (appointmentDesc.length() > APPOINTMENT_DESCRIPTION_LENGTH) {
			throw new IllegalArgumentException("Appointment description cannot exceed " 
												+ APPOINTMENT_DESCRIPTION_LENGTH 
												+ " characters.");
		}
		else {
			this.appointmentDesc = appointmentDesc;
		}
	}
	
}
