package main;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContactService {
	
	//initializes List for use to retain data
	private List<Contact> ContactList = new ArrayList<>();
	
	
	public void newContact() {
		Contact contact = new Contact(newUniqueID());
		ContactList.add(contact);
	}//default constructor
	
	public void newContact(String firstName) {
		Contact contact = new Contact(newUniqueID(), firstName);
		ContactList.add(contact);
	}//constructor if first name is given
	
	public void newContact(String firstName, String lastName) {
		Contact contact = new Contact(newUniqueID(), firstName, lastName);
		ContactList.add(contact);
	}//constructor if full name is given
	
	public void newContact(String firstName, String lastName, String phoneNumber) {
		Contact contact = new Contact(newUniqueID(), firstName, lastName, phoneNumber);
		ContactList.add(contact);
	}//constructor if all but address is given
	
	public void newContact(String firstName, String lastName, String phoneNumber, String address) {
		Contact contact = new Contact(newUniqueID(), firstName, lastName, phoneNumber, address);
		ContactList.add(contact);
	}//constructor if all info is given
	
	public void deleteContact(String contactID) throws Exception {
		ContactList.remove(searchForContact(contactID));
	}//removes contact from list if not already removed
	
	public void updateFirstName(String contactID, String firstName) throws Exception {
		searchForContact(contactID).updateFirstName(firstName);
	}//updates first name as needed
	
	public void updateLastName(String contactID, String lastName) throws Exception {
		searchForContact(contactID).updateLastName(lastName);
	}//updates last name as needed
	
	public void updatePhoneNumber(String contactID, String phoneNumber) throws Exception {
		searchForContact(contactID).updatePhoneNumber(phoneNumber);
	}//updates phone number as needed
	
	public void updateAddress(String contactID, String address) throws Exception {
		searchForContact(contactID).updateAddress(address);
	}//updates address as needed
	
	public List<Contact> getContactList(){
		return ContactList;
	}//returns list of contacts as needed
	
	private String newUniqueID() {
		return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}// creates a unique id for each new user entered into the system
	
	private Contact searchForContact(String contactID) throws Exception {
		int index = 0;
		while (index < ContactList.size()) {
			if(contactID.equals(ContactList.get(index).getContactID())) {
				return ContactList.get(index);
			}//if contact id has been found, return where it was found
			index++;
		}//loops through list until reaching the end
		throw new Exception("That ID does not exist");
	}//allows the system to look for contacts
}
