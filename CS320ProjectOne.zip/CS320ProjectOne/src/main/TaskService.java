package main;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TaskService {

	private final List<Task> taskList = new ArrayList<>();
	
	private String newUniqueUUID() {
		return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	private Task searchForTaskID(String taskID) throws Exception {
		int index = 0;
		while (index < taskList.size()) {
			if(taskID.equals(taskList.get(index).getTaskID())) {
				return taskList.get(index);
			}
			index++;
		}
		throw new Exception("This Task does not exist in the system");
	}
	
	public void newTask() {
		Task task = new Task(newUniqueUUID());
		taskList.add(task);
	}
	
	public void newTask(String taskName) {
		Task task = new Task(newUniqueUUID(), taskName);
		taskList.add(task);
	}
	
	public void newTask(String taskName, String taskDescription) {
		Task task = new Task(newUniqueUUID(), taskName, taskDescription);
		taskList.add(task);
	}
	
	public void deleteTask(String taskID) throws Exception {
		taskList.remove(searchForTaskID(taskID));
	}
	
	public void updateTaskName(String taskID, String newName) throws Exception {
		searchForTaskID(taskID).setTaskName(newName);
	}
	
	public void updateTaskDescription(String taskID, String newDesc) throws Exception {
		searchForTaskID(taskID).setTaskDescription(newDesc);
	}
	
	public List<Task> getTaskList() {
		return taskList;
	}
}
