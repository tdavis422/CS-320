package main;

public class Task {

	private String taskID;
	private String taskName;
	private String taskDescription;
	
	public Task(){
		taskID = "STARTER";
		taskName = "STARTER";
		taskDescription = "STARTER";
	}
	
	public Task(String taskID) {
		verifyTaskID(taskID);
		taskName = "STARTER";
		taskDescription = "STARTER";
	}
	
	public Task(String taskID, String taskName) {
		verifyTaskID(taskID);
		setTaskName(taskName);
		taskDescription = "STARTER";
	}
	
	public Task(String taskID, String taskName, String taskDescription) {
		verifyTaskID(taskID);
		setTaskName(taskName);
		setTaskDescription(taskDescription);
	}
	
	public final String getTaskID() {
		return taskID;
	}
	
	public final String getTaskName() {
		return taskName;
	}
	
	public final String getTaskDescription() {
		return taskDescription;
	}
	
	public void setTaskName(String taskName) {
		if(taskName == null) {
			throw new IllegalArgumentException("Task name is invalid. Ensure name has been entered.");
		}
		else if (taskName.length() > 20) {
			throw new IllegalArgumentException("Task name is invalid. Ensure name is less than 20 characters.");
		}
		else {
			this.taskName = taskName;
		}
	}
	
	public void setTaskDescription(String taskDescription) {
		if(taskDescription == null) {
			throw new IllegalArgumentException("Task description is emply. Please enter and try again.");
		}
		else if(taskDescription.length() > 50) {
			throw new IllegalArgumentException("Task description must be 50 characters or less.");
		}
		else {
			this.taskDescription = taskDescription;
		}
	}
	
	public void verifyTaskID(String taskID) {
		if(taskID == null) {
			throw new IllegalArgumentException("Task ID is empty. Please enter and try again.");
		}
		else if(taskID.length() > 10) {
			throw new IllegalArgumentException("Task ID must be 10 characters or less.");
		}
		else {
			this.taskID = taskID;
		}
	}
}
