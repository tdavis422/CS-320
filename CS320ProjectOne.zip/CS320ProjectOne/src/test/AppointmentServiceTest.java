package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import main.AppointmentService;

class AppointmentServiceTest {

	private String apptID, apptDescription, tooLongApptDescription;
	private Date apptDate, apptPastDate;
	
	//set up all data required for tests
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setup() {
		apptID = "0D12FE0A5D";
		apptDescription = "The description field shall not be null.";
		apptDate = new Date(2023, Calendar.SEPTEMBER, 27);
		tooLongApptDescription = "Make sure you’ve included all the required "
				+ "elements by reviewing the guidelines and rubric.";
		apptPastDate = new Date(0);
	}
	
	@Test
	void testNewAppointment() {
		AppointmentService service = new AppointmentService();
		
		//initialize first set of data
		service.newAppointment();
		assertNotNull(service.getAppointmentList().get(0).getAppointmentID());
		assertNotNull(service.getAppointmentList().get(0).getAppointmentDate());
		assertNotNull(service.getAppointmentList().get(0).getAppointmentDesc());
		
		//initialize second set of data
		service.newAppointment(apptDate);
		assertNotNull(service.getAppointmentList().get(1).getAppointmentID());
		assertEquals(apptDate, service.getAppointmentList().get(1).getAppointmentDate());
		assertNotNull(service.getAppointmentList().get(1).getAppointmentDesc());
		
		//initialize third set of data
		service.newAppointment(apptDate, apptDescription);
		assertNotNull(service.getAppointmentList().get(2).getAppointmentID());
		assertEquals(apptDate, service.getAppointmentList().get(2).getAppointmentDate());
		assertEquals(apptDescription, service.getAppointmentList().get(2).getAppointmentDesc());
		
		//verify all appointment IDs are unique
		assertNotEquals(service.getAppointmentList().get(0).getAppointmentID(), 
						service.getAppointmentList().get(1).getAppointmentID());
		assertNotEquals(service.getAppointmentList().get(0).getAppointmentID(),
						service.getAppointmentList().get(2).getAppointmentID());
		assertNotEquals(service.getAppointmentList().get(1).getAppointmentID(),
						service.getAppointmentList().get(2).getAppointmentID());
		
		//verify pastDate and tooLongDescription fail
		assertThrows(IllegalArgumentException.class, () -> service.newAppointment(apptPastDate));
		assertThrows(IllegalArgumentException.class, () -> service.newAppointment(apptDate, tooLongApptDescription));
		
	}
	
	@Test
	void testDeleteAppointment() throws Exception {
		AppointmentService service = new AppointmentService();
		
		service.newAppointment();
		service.newAppointment();
		service.newAppointment();
		
		String firstApptID = service.getAppointmentList().get(0).getAppointmentID();
		String secondApptID = service.getAppointmentList().get(1).getAppointmentID();
		String thirdApptID = service.getAppointmentList().get(2).getAppointmentID();
		
		assertNotEquals(firstApptID, secondApptID);
		assertNotEquals(firstApptID, thirdApptID);
		assertNotEquals(secondApptID, thirdApptID);
		
		assertNotEquals(apptID, firstApptID);
		assertNotEquals(apptID, secondApptID);
		assertNotEquals(apptID, thirdApptID);
		
		assertThrows(Exception.class, () -> service.deleteAppointment(apptID));
		
		service.deleteAppointment(firstApptID);
		assertThrows(Exception.class, () -> service.deleteAppointment(firstApptID));
		assertNotEquals(firstApptID, service.getAppointmentList().get(0).getAppointmentID());
	}

}
