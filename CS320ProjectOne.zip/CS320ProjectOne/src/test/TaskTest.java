package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Task;

class TaskTest {

	private String taskID, taskName, taskDesc;
	private String tooLongTaskID, tooLongTaskName, tooLongTaskDesc;
	private String tooShortTaskID, tooShortTaskName, tooShortTaskDesc;
	
	@BeforeEach
	void setup() {
		taskID = "6d9a9ed65a";
		taskName = "The future is now.";
		taskDesc = "The task object shall have a required name field.";
		
		tooLongTaskID = "2d54788c5a1b11ee8c990242ac120002";
		tooLongTaskName = "When it rains, look for rainbows";
		tooLongTaskDesc = "The task object shall have a required description "
				+ "String field that cannot be longer than 50 characters";
		
		tooShortTaskID = "94DBA";
		tooShortTaskName = "Birth";
		tooShortTaskDesc = "Scheduled Birth";
	}
	
	@Test
	void getTaskIDTest() {
		Task task = new Task(taskID);
		assertEquals(taskID, task.getTaskID());
	}
	
	@Test
	void getTaskNameTest() {
		Task task = new Task(taskID, taskName);
		assertEquals(taskName, task.getTaskName());
	}
	
	@Test
	void getTaskDescriptionTest() {
		Task task = new Task(taskID, taskName, taskDesc);
		assertEquals(taskDesc, task.getTaskDescription());
	}
	
	@Test
	void setTaskNameTest() {
		Task task = new Task(taskID);
		task.setTaskName(taskName);
		assertEquals(taskName, task.getTaskName());
	}
	
	@Test
	void setTaskDescriptionTest() {
		Task task = new Task(taskID);
		task.setTaskDescription(taskDesc);
		assertEquals(taskDesc, task.getTaskDescription());
	}
	
	@Test
	void TaskIDTooLongTest() {
		assertThrows(IllegalArgumentException.class, () -> new Task(tooLongTaskID));
	}
	
	@Test
	void setTooLongTaskNameTest() {
		Task task = new Task();
		assertThrows(IllegalArgumentException.class, () -> task.setTaskName(tooLongTaskName));
	}
	
	@Test
	void setTooLongTaskDescTest() {
		Task task = new Task();
		assertThrows(IllegalArgumentException.class, () -> task.setTaskDescription(tooLongTaskDesc));
	}
	
	@Test
	void TaskIDNullTest() {
		assertThrows(IllegalArgumentException.class, () -> new Task(null));
	}
	
	@Test
	void TaskNameNullTest() {
		Task task = new Task();
		assertThrows(IllegalArgumentException.class, () -> task.setTaskName(null));
	}
	
	@Test
	void TaskDescNullTest() {
		Task task = new Task();
		assertThrows(IllegalArgumentException.class, () -> task.setTaskDescription(null));
	}
	
	@Test
	void setTaskIDTooShortTest() {
		Task task = new Task();
		task.verifyTaskID(tooShortTaskID);
		assertEquals(tooShortTaskID, task.getTaskID());
	}
	
	@Test
	void setTaskNameTooShortTest() {
		Task task = new Task();
		task.setTaskName(tooShortTaskName);
		assertEquals(tooShortTaskName, task.getTaskName());
	}
	
	@Test
	void setTaskDescTooShortTest() {
		Task task = new Task();
		task.setTaskDescription(tooShortTaskDesc);
		assertEquals(tooShortTaskDesc, task.getTaskDescription());
	}

}
