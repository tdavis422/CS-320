package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Contact;

public class ContactTest {
	protected String contactID, firstNameTest, lastNameTest, phoneNumberTest,
	addressTest;
	protected String tooLongContactID, tooLongFirstName, tooLongLastName,
	tooLongPhoneNumber, tooShortPhoneNumber, tooLongAddress, tooShortFirstName,
	tooShortLastName, tooShortContactID, tooShortAddress;

	@BeforeEach
	void setUp() {
		contactID = "1E1434EDC8";
		firstNameTest = "Carmichael";
		lastNameTest = "Charleston";
		phoneNumberTest = "0123456789";
		addressTest = "1 Audrey Jersey City NJ 07305";
		
		tooLongContactID = "F43DA7751F5F40AE";
		tooLongFirstName = "Christopher";
		tooLongLastName = "Remingtonlee";
		tooLongPhoneNumber = "123456789123456";
		tooLongAddress = "2451 S Springfield Ave, Bolivar, MO 65613";
		
		tooShortFirstName = "Ava";
		tooShortLastName = "Buck";
		tooShortContactID = "A4ECE";
		tooShortPhoneNumber = "98765";
		tooShortAddress = "123 Main Ave Butler MO";
	}

	@Test
	void contactTest() {
		Contact contact = new Contact();
		assertAll("constructor",
				()
				-> assertNotNull(contact.getContactID()),
				()
				-> assertNotNull(contact.getFirstName()),
				()
				-> assertNotNull(contact.getLastName()),
				()
				-> assertNotNull(contact.getPhoneNumber()),
				() 
				-> assertNotNull(contact.getAddress()));
	}

	@Test
	void contactIdConstructorTest() {
		Contact contact = new Contact(contactID);
		assertAll("constructor one",
				()
				-> assertEquals(contactID, contact.getContactID()),
				()
				-> assertNotNull(contact.getFirstName()),
				()
				-> assertNotNull(contact.getLastName()),
				()
				-> assertNotNull(contact.getPhoneNumber()),
				() 
				-> assertNotNull(contact.getAddress()));
	}

	@Test
	void contactIdAndFirstNameConstructorTest() {
		Contact contact = new Contact(contactID, firstNameTest);
		assertAll("constructor two",
				()
				-> assertEquals(contactID, contact.getContactID()),
				()
				-> assertEquals(firstNameTest, contact.getFirstName()),
				()
				-> assertNotNull(contact.getLastName()),
				()
				-> assertNotNull(contact.getPhoneNumber()),
				() 
				-> assertNotNull(contact.getAddress()));
	}

	@Test
	void contactIdAndFullNameConstructorTest() {
		Contact contact = new Contact(contactID, firstNameTest, lastNameTest);
		assertAll("constructor three",
				()
				-> assertEquals(contactID, contact.getContactID()),
				()
				-> assertEquals(firstNameTest, contact.getFirstName()),
				()
				-> assertEquals(lastNameTest, contact.getLastName()),
				()
				-> assertNotNull(contact.getPhoneNumber()),
				() 
				-> assertNotNull(contact.getAddress()));
	}

	@Test
	void contactIdFullNamePhoneNumberConstructorTest() {
		Contact contact =
				new Contact(contactID, firstNameTest, lastNameTest, phoneNumberTest);
		assertAll("constructor four",
				()
				-> assertEquals(contactID, contact.getContactID()),
				()
				-> assertEquals(firstNameTest, contact.getFirstName()),
				()
				-> assertEquals(lastNameTest, contact.getLastName()),
				()
				-> assertEquals(phoneNumberTest, contact.getPhoneNumber()),
				() 
				-> assertNotNull(contact.getAddress()));
	}

	@Test
	void allTheProperThingsConstructorTest() {
		Contact contact = new Contact(contactID, firstNameTest, lastNameTest,
				phoneNumberTest, addressTest);
		assertAll("constructor all",
				()
				-> assertEquals(contactID, contact.getContactID()),
				()
				-> assertEquals(firstNameTest, contact.getFirstName()),
				()
				-> assertEquals(lastNameTest, contact.getLastName()),
				()
				-> assertEquals(phoneNumberTest, contact.getPhoneNumber()),
				() 
				-> assertEquals(addressTest, contact.getAddress()));
	}

	@Test
	void updateFirstNameTest() {
		Contact contact = new Contact();
		contact.updateFirstName(firstNameTest);
		assertEquals(firstNameTest, contact.getFirstName());
	}
	
	@Test
	void updateFirstNameTooLongTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class,() -> contact.updateFirstName(tooLongFirstName));
	}
	
	@Test
	void updateFirstNameShortTest() {
		Contact contact = new Contact();
		contact.updateFirstName(tooShortFirstName);
		assertEquals(tooShortFirstName, contact.getFirstName());
	}
	
	@Test
	void updateFirstNameNullTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class, () -> contact.updateFirstName(null));
	}

	@Test
	void updateLastNameTest() {
		Contact contact = new Contact();
		contact.updateLastName(lastNameTest);
		assertEquals(lastNameTest, contact.getLastName());
	}
	
	@Test
	void updateLastNameTooLongTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class, () -> contact.updateLastName(tooLongLastName));
	}
	
	@Test
	void updateLastNameTooShortTest() {
		Contact contact = new Contact();
		contact.updateLastName(tooShortLastName);
		assertEquals(tooShortLastName, contact.getLastName());
	}
	
	@Test
	void updateLastNameNullTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class, () -> contact.updateLastName(null));
	}

	@Test
	void updatePhoneNumberTest() {
		Contact contact = new Contact();
		contact.updatePhoneNumber(phoneNumberTest);
		assertAll("phone number",
				()
				-> assertEquals(phoneNumberTest, contact.getPhoneNumber()),
				()
				-> assertThrows(IllegalArgumentException.class,
						() -> contact.updatePhoneNumber(null)),
				()
				-> assertThrows(
						IllegalArgumentException.class,
						() -> contact.updatePhoneNumber(tooLongPhoneNumber)),
				()
				-> assertThrows(
						IllegalArgumentException.class,
						() -> contact.updatePhoneNumber(tooShortPhoneNumber)),
				()
				-> assertThrows(IllegalArgumentException.class,
						() -> contact.updatePhoneNumber(contactID)));
	}

	@Test
	void updateAddressTest() {
		Contact contact = new Contact();
		contact.updateAddress(addressTest);
		assertEquals(addressTest, contact.getAddress());
	}
	
	@Test
	void updateAddressTooLongTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class, () -> contact.updateAddress(tooLongAddress));
	}
	
	@Test
	void updateAddressTooShortTest() {
		Contact contact = new Contact();
		contact.updateAddress(tooShortAddress);
		assertEquals(tooShortAddress, contact.getAddress());
	}
	
	@Test
	void updateAddressNullTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class, () -> contact.updateAddress(null));
	}

	@Test
	void updateContactIdTest() {
		Contact contact = new Contact();
		contact.verifyContactID(contactID);
		assertEquals(contactID, contact.getContactID());
	}
	
	@Test
	void updateContactIDTooLongTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class, () -> contact.verifyContactID(tooLongContactID));
	}
	
	@Test
	void updateContactIDTooShortTest() {
		Contact contact = new Contact();
		contact.verifyContactID(tooShortContactID);
		assertEquals(tooShortContactID, contact.getContactID());
	}
	
	@Test
	void updateContactIDNullTest() {
		Contact contact = new Contact();
		assertThrows(IllegalArgumentException.class, () -> contact.verifyContactID(null));
	}

}
