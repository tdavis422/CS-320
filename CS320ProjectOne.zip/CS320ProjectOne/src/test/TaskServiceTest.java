package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import main.TaskService;

class TaskServiceTest {
	
	private String taskID, taskName, taskDesc, taskTooLongName, taskTooLongDesc;
	
	@BeforeEach
	void setup() {
		taskID = "6d9a9ed65a";
		taskName = "The future is now.";
		taskDesc = "The task object shall have a required name field.";
		taskTooLongName = "When it rains, look for rainbows";
		taskTooLongDesc = "The task object shall have a required description "
				+ "String field that cannot be longer than 50 characters";
	}
	
	@Test
	void newTaskTest() {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertNotNull(service.getTaskList().get(0).getTaskID());
		Assertions.assertNotEquals("STARTER", service.getTaskList().get(0).getTaskID());
	}
	
	@Test
	void newTaskNameTest() {
	    TaskService service = new TaskService();
	    service.newTask(taskName);
	    Assertions.assertNotNull(service.getTaskList().get(0).getTaskName());
	    Assertions.assertEquals(taskName, service.getTaskList().get(0).getTaskName());
	}
	
	@Test
	void newTaskDescName() {
		TaskService service = new TaskService();
		service.newTask(taskName, taskDesc);
		Assertions.assertNotNull(service.getTaskList().get(0).getTaskDescription());
		Assertions.assertEquals(taskDesc, service.getTaskList().get(0).getTaskDescription());
	}
	
	@Test
	void newTaskNameTooLongTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.newTask(taskTooLongName));
	}
	
	@Test
	void newTaskDescTooLongTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.newTask(taskName, taskTooLongDesc));
	}
	
	@Test
	void newTaskNameNullTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.newTask(null));
	}
	
	@Test
	void newTaskDescNullTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.newTask(taskName, null));
	}
	
	@Test
	void deleteTaskTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertEquals(1, service.getTaskList().size());
		service.deleteTask(service.getTaskList().get(0).getTaskID());
		Assertions.assertEquals(0, service.getTaskList().size());
	}
	
	@Test
	void deleteTaskNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertEquals(1, service.getTaskList().size());
		Assertions.assertThrows(Exception.class, () -> service.deleteTask(taskID));
		Assertions.assertEquals(1, service.getTaskList().size());
	}
	
	@Test
	void updateTaskNameTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateTaskName(service.getTaskList().get(0).getTaskID(), taskName);
		Assertions.assertEquals(taskName, service.getTaskList().get(0).getTaskName());
	}
	
	@Test
	void updateTaskDescriptionTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateTaskDescription(service.getTaskList().get(0).getTaskID(), taskDesc);
		assertEquals(taskDesc, service.getTaskList().get(0).getTaskDescription());
	}
	
	@Test
	void updateTaskNameNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertThrows(Exception.class, () -> service.updateTaskName(taskID, taskDesc));
	}
	
	@Test
	void updateTaskDescNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertThrows(Exception.class, () -> service.updateTaskDescription(taskID, taskDesc));
	}
	
	@RepeatedTest(4)
	void UUIDTest() {
		TaskService service = new TaskService();
		service.newTask();
		service.newTask();
		service.newTask();
		Assertions.assertEquals(3, service.getTaskList().size());
		Assertions.assertNotEquals(service.getTaskList().get(0).getTaskID(), service.getTaskList().get(1).getTaskID());
		Assertions.assertNotEquals(service.getTaskList().get(0).getTaskID(), service.getTaskList().get(2).getTaskID());
		Assertions.assertNotEquals(service.getTaskList().get(1).getTaskID(), service.getTaskList().get(2).getTaskID());
	}
	
}
