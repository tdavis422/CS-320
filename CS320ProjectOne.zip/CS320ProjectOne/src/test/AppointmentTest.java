package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.util.Calendar;
import java.util.Date;

import main.Appointment;

class AppointmentTest {

	private String apptID, tooLongApptID, tooShortApptID;
	private String apptDescription, tooLongApptDescription, tooShortApptDescription;
	private Date apptDate, apptPastDate, apptFutureDate;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setup() {
		apptID = "7E4BF7245D";
		apptDescription = "The description field shall not be null.";
		apptDate = new Date(2023, Calendar.SEPTEMBER, 27);
		
		tooLongApptID = "d610e2da-5d95-11ee-8c99-0242ac120002";
		tooLongApptDescription = "Make sure you’ve included all the required "
								+ "elements by reviewing the guidelines and rubric.";
		apptPastDate = new Date(0);
		
		tooShortApptID = "D610E";
		tooShortApptDescription = "";
		apptFutureDate = new Date(2023, Calendar.OCTOBER, 3);
	}
	
	@Test
	void testGetAppointmentID() {
		Appointment appt = new Appointment(apptID);
		assertNotNull(appt.getAppointmentID());
		assertEquals(appt.getAppointmentID().length(), 10);
		assertEquals(apptID, appt.getAppointmentID());
	}
	
	@Test
	void testGetAppointmentDate() {
		Appointment appt = new Appointment(apptID, apptDate);
		assertNotNull(appt.getAppointmentDate());
		assertEquals(apptDate, appt.getAppointmentDate());
	}
	
	@Test
	void testGetAppointmentDesc() {
		Appointment appt = new Appointment(apptID, apptDate, apptDescription);
		assertNotNull(appt.getAppointmentDesc());
		assertTrue(appt.getAppointmentDesc().length() <= 50);
		assertEquals(apptDescription, appt.getAppointmentDesc());
	}
	
	@Test
	void testVerifyAppointmentID() {
		Appointment appt = new Appointment();
		assertThrows(IllegalArgumentException.class, () -> appt.verifyAppointmentID(null));
		assertThrows(IllegalArgumentException.class, () -> appt.verifyAppointmentID(tooLongApptID));
		appt.verifyAppointmentID(apptID);
		assertEquals(apptID, appt.getAppointmentID());
		appt.verifyAppointmentID(tooShortApptID);
		assertEquals(tooShortApptID, appt.getAppointmentID());
	}
	
	@Test
	void testVerifyAppointmentDate() {
		Appointment appt = new Appointment();
		assertThrows(IllegalArgumentException.class, () -> appt.verifyAppointmentDate(null));
		assertThrows(IllegalArgumentException.class, () -> appt.verifyAppointmentDate(apptPastDate));
		appt.verifyAppointmentDate(apptDate);
		assertEquals(apptDate, appt.getAppointmentDate());
		appt.verifyAppointmentDate(apptFutureDate);
		assertEquals(apptFutureDate, appt.getAppointmentDate());
	}
	
	@Test
	void testVerifyAppointmentDescription() {
		Appointment appt = new Appointment();
		assertThrows(IllegalArgumentException.class, () -> appt.verifyAppointmentDescription(null));
		assertThrows(IllegalArgumentException.class, () -> appt.verifyAppointmentDescription(tooLongApptDescription));
		appt.verifyAppointmentDescription(apptDescription);
		assertEquals(apptDescription, appt.getAppointmentDesc());
		appt.verifyAppointmentDescription(tooShortApptDescription);
		assertEquals(tooShortApptDescription, appt.getAppointmentDesc());
	}
	
}
